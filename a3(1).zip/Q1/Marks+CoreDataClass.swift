//
//  Marks+CoreDataClass.swift
//  Q1
//
//  Created by MSCICT2 on 4/8/24.
//
//

import Foundation
import CoreData

@objc(Marks)
public class Marks: NSManagedObject {

}
