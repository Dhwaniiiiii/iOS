//
//  ViewController.swift
//  Q1
//
//  Created by MSCICT2 on 4/8/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

