//
//  ViewController.swift
//  Q2
//
//  Created by MSCICT2 on 4/9/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

