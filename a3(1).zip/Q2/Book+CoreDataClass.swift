//
//  Book+CoreDataClass.swift
//  Q2
//
//  Created by MSCICT2 on 4/9/24.
//
//

import Foundation
import CoreData

@objc(Book)
public class Book: NSManagedObject {

}
