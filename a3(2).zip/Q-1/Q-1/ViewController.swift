//
//  ViewController.swift
//  Q-1
//
//  Created by MSCICT2 on 08/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

