//
//  Stud_marks+CoreDataClass.swift
//  Q-1
//
//  Created by MSCICT2 on 08/04/24.
//
//

import Foundation
import CoreData

@objc(Stud_marks)
public class Stud_marks: NSManagedObject {

}
