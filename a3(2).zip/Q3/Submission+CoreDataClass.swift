//
//  Submission+CoreDataClass.swift
//  Q3
//
//  Created by MSCICT2 on 4/9/24.
//
//

import Foundation
import CoreData

@objc(Submission)
public class Submission: NSManagedObject {

}
