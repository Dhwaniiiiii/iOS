//
//  Book+CoreDataClass.swift
//  Q-2
//
//  Created by Harsh on 10/04/24.
//
//

import Foundation
import CoreData

@objc(Book)
public class Book: NSManagedObject {

}
