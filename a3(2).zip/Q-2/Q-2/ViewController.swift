//
//  ViewController.swift
//  Q-2
//
//  Created by Harsh on 10/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

