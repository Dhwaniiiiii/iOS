//
//  BookIssueReturn+CoreDataClass.swift
//  Q-2
//
//  Created by Harsh on 10/04/24.
//
//

import Foundation
import CoreData

@objc(BookIssueReturn)
public class BookIssueReturn: NSManagedObject {

}
