//
//  ViewController.swift
//  curr_location_demo
//
//  Created by MAC on 3/13/23.
//

import UIKit
import CoreLocation
class ViewController: UIViewController, CLLocationManagerDelegate {
    var clm:CLLocationManager?
    var geo:CLGeocoder?
    var places:CLPlacemark?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.geo=CLGeocoder()
        self.clm=CLLocationManager()
        self.clm?.delegate=self
        self.clm?.desiredAccuracy=kCLLocationAccuracyBest
        self.clm?.requestWhenInUseAuthorization()
        self.clm?.startUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        var myloc=locations.first
        //print(myloc?.coordinate.latitude)
//print(myloc?.coordinate.longitude)
       /*
        geo?.geocodeAddressString("Surat, India", completionHandler: {_,_ in
            do {
                print(locations.last?.coordinate.latitude)
                print(locations.last?.coordinate.longitude)
            }
            // 0
        })
 */
        geo?.reverseGeocodeLocation(CLLocation(latitude: 21.170240, longitude: 72.831062)) { (placemarks, error) in
                if error != nil {
                    print("something went horribly wrong")
                }
                if let placemarks = placemarks {
                    self.places = placemarks.first
                    print(self.places?.country! as Any)
                    print(self.places?.administrativeArea! as Any)
                    print(self.places?.postalCode! as Any)

                }
            }

    }

}

