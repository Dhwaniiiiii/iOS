//
//  ViewController.swift
//  Data_sharing1
//
//  Created by MAC on 1/25/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var uname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        performSegue(withIdentifier: "s1", sender: self)
        
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if( segue.identifier == "s1")
        {
            var dest = segue.destination as! dvc
            dest.str = uname.text!
            
        }
    }
}

