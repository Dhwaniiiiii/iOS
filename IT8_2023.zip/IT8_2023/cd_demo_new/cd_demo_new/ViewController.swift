//
//  ViewController.swift
//  cd_demo_new
//
//  Created by MAC on 2/8/23.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_add(_ sender: Any) {
        let appD = UIApplication.shared.delegate as! AppDelegate
        let context = appD.persistentContainer.viewContext
        let newItem = NSEntityDescription.insertNewObject(forEntityName: "Stud", into: context)
        newItem.setValue(1, forKey: "sid")
        newItem.setValue("Aakash", forKey: "sname")
        newItem.setValue(30, forKey: "sage")
        do{
            try context.save()
            print("Record inserted.....")
        }catch{
            print("Error in inserting......")
        }
        
    }
    
    @IBAction func btn_show(_ sender: Any) {
        let appD2 = UIApplication.shared.delegate as! AppDelegate
        let context2 = appD2.persistentContainer.viewContext
        let fr = NSFetchRequest<NSFetchRequestResult>(entityName: "Stud")
        do{
            let result = try context2.fetch(fr)
            for data in result as! [NSObject] {
                print(data.value(forKey: "sid")!)
                print(data.value(forKey: "sname")!)
                print(data.value(forKey: "sage")!)
            }
        }catch{
                print("Error in fetching records.....")
        }
        
    }
    @IBAction func btn_update(_ sender: Any) {
        let appD3 = UIApplication.shared.delegate as! AppDelegate
        let context3 = appD3.persistentContainer.viewContext
        let fr = NSFetchRequest<NSFetchRequestResult>(entityName: "Stud")
        fr.predicate = NSPredicate(format: "sname=%@", "Aakash")
        do{
            /* Update record
            let test = try context3.fetch(f.
             
             
             
             
             
             
             r)
            let obj = test[0] as! NSObject
            obj.setValue("Bharat", forKey: "sname")
            */
            
            
            // delete nrecord
            let test = try context3.fetch(fr)
            let obj = test[0] as! NSObject
           // context3.delete(obj)
            
            do{
                try context3.save()
            }catch{
                
            }
        }catch{
            
        }
        
    }
    
    @IBAction func btn_delete(_ sender: Any) {
        let appD4 = UIApplication.shared.delegate as! AppDelegate
        let context4 = appD4.persistentContainer.viewContext
        let fr = NSFetchRequest<NSFetchRequestResult>(entityName: "Stud")
        fr.predicate = NSPredicate(format: "sname=%@", "Bharat")
        do{
            let test = try context4.fetch(fr)
            let obj = test[0] as! NSManagedObject
            context4.delete(obj)
            try context4.save()
        }catch{
            
        }
        
        
    }
    
}

