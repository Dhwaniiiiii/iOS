//
//  ViewController.swift
//  map_demo
//
//  Created by MAC on 3/15/23.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController {

    @IBOutlet weak var mymapview: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let location:CLLocationCoordinate2D=CLLocationCoordinate2D(latitude: 21.1702, longitude: 72.8311)
        let span:MKCoordinateSpan=MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region:MKCoordinateRegion=MKCoordinateRegion(center: location, span: span)
        mymapview.setRegion(region, animated: true)
        self.mymapview.showsUserLocation=true
        
        let ant:MKPointAnnotation=MKPointAnnotation()
       // ant.coordinate(location) as! CLLocationCoordinate2D
        ant.title="Where am I?"
        ant.subtitle="I am at VNSGU"
        
        ant.coordinate=CLLocationCoordinate2D(latitude: 21.1535, longitude: 72.7832)
        mymapview.addAnnotation(ant)
        
        
    }


}

