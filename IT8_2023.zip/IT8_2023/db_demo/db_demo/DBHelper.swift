//
//  DBHelper.swift
//  db_demo
//
//  Created by MAC on 2/1/23.
//

import Foundation
import SQLite3
class DBHelper {
    init()
    {
        db = openDatabase()
        createTable()
    }
    var dbPath:String = "myDB.sqlite"
    var db:OpaquePointer?
    func openDatabase() -> OpaquePointer?
    {
        var filePath = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent(dbPath)
        var db:OpaquePointer? = nil
        if sqlite3_open(filePath.path, &db) != SQLITE_OK
        {
            print("error opening database")
            return nil
        }
        else{
            print("Database opened")
            return db!
        }
    }
    
    func createTable()
     {
        var str = "create table if not exists stud(id integer primary key, name text, age integer)"
        var strstmt: OpaquePointer?
        if sqlite3_prepare_v2(db, str, -1,  &strstmt, nil) == SQLITE_OK
        {
            if sqlite3_step(strstmt) == SQLITE_DONE
            {
                print("Table created")
            } else
            {
                print("Error in table creation")
            }
        }else
        {
            print("error in compilation")
        }
        sqlite3_finalize(strstmt)
    }
    func insertrec(id:Int, name:String, age:Int)
    {
        var insertstr = " insert into stud(id, name, age) values(?,?,?)"
        var insertstmt: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, insertstr, -1, &insertstmt, nil) == SQLITE_OK
        {
            sqlite3_bind_int(insertstmt, 1, Int32(id))
            sqlite3_bind_text(insertstmt, 2, (name as NSString).utf8String, -1, nil  )
            sqlite3_bind_int(insertstmt, 3, Int32(age))
            
            if sqlite3_step(insertstmt) == SQLITE_DONE
            {
                print("Record Inserted")
            }
            else{
                print("Error in record insertion")
            }
            
        }else
        {
            print("error in isert compilation")
        }
        sqlite3_finalize(insertstmt)
    }
    func disply()
    {
        var disp="select * from stud"
        var dispstmt: OpaquePointer? = nil
        var studs: [Any] = []
         if sqlite3_prepare(db, disp, -1, &dispstmt, nil) == SQLITE_OK
         {
            while sqlite3_step(dispstmt) == SQLITE_ROW
            {
                let sid = sqlite3_column_int(dispstmt, Int32(0))
                let sname = String(describing: String(cString: sqlite3_column_text(dispstmt, 1)))
                let sage = sqlite3_column_int(dispstmt, Int32(2))
                
               
                    print("\(sid) | \(sname) | \(sage)")
                
            }
            sqlite3_finalize(dispstmt)
         }
    }
    
    func del(id: Int)
    {
        let delstr = " delete from stud where id=? "
        var delstmt: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, delstr, -1, &delstmt, nil) == SQLITE_OK
        {
            sqlite3_bind_int(delstmt, 1, Int32(id))
                       
            if sqlite3_step(delstmt) == SQLITE_DONE
            {
                print("Record Deleted")
            }
            else{
                print("Error in record deletion")
            }
            
        }else
        {
            print("error in isert compilation")
        }
        sqlite3_finalize(delstmt)

    }
    
}
