//
//  ViewController.swift
//  db_demo
//
//  Created by MAC on 2/1/23.
//

import UIKit

class ViewController: UIViewController {
    var db = DBHelper()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //db.insertrec(id: 1, name: "Manish", age: 25)
        //db.disply()
        db.del(id: 1)
    }


}

