//
//  ViewController.swift
//  It_table_demo
//
//  Created by MAC on 2/10/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return city.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: ci) as! UITableViewCell
        var cell:UITableViewCell=tableView.dequeueReusableCell(withIdentifier: ci, for: indexPath) as! UITableViewCell
        cell.textLabel?.text = city[indexPath.row]
        //var  city[indexPath.row]
        return cell
    }
    
    
    var city:[String]=["Surat", "Navsari", "Mumbai", "Vadodara"]
    @IBOutlet weak var tv: UITableView!
    var ci="cell"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tv.register(UITableViewCell.self, forCellReuseIdentifier: ci)
        tv.delegate=self
        tv.dataSource=self
    }


}

