//
//  ViewController.swift
//  img_demo
//
//  Created by MAC on 3/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myimg: UIImageView!
    var myimages=[(UIImage(named: "img1.jpeg"),UIImage(named: "img2.jpeg"),UIImage(named: (UIImage(named: "img3.jpeg")]    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //myimg.image=UIImage(named: "439.jpg")
//.myimg.animationImages=(UIImage(named: myimages) ?? UIImage) as UIImage
        //myimg.animationImages=UIImage( "img1.jpeg","img2.jpeg","img3.jpeg","img4.jpeg")
       // myimg.animationImages=UIImage(named: myimages, in: nil, with: myimages)
        self.myimg.animationImages=myimages
        
    }
    }




