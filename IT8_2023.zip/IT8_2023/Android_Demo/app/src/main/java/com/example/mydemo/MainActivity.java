package com.example.mydemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.e1);
        b1=findViewById(R.id.b1);


        SharedPreferences spf2=getSharedPreferences("mypref", MODE_PRIVATE);
        if(spf2.contains("name"))
        {
            ed1.setText(spf2.getString("name",""));
        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences spf=getSharedPreferences("mypref", MODE_PRIVATE);
                SharedPreferences.Editor edit=spf.edit();
                edit.putString("name", ed1.getText().toString());
                edit.apply();
            }
        });
    }
}