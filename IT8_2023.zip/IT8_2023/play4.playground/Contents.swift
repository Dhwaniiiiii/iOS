import UIKit

// Protocol Demo
/*

protocol pro1{
    func show()
}
protocol  pro2 {
    func display()
}
class abc:pro1,pro2
{
    func display() {
        print("display method of pro2....")
    }
    var name="manish"
    func show() {
        print("welcome  \(name)")
    }
    
}
var obj=abc()
obj.show()
obj.display()
*/


//Extension Demo
/*
class abc
{
    func show()
    {
        print("Welcome to iOS......")
    }
}
extension abc
{
    func  display(){
        print("iOS Programming....")
    }
    
}
var obj=abc()
obj.show()
obj.display()
*/

//Structure Demo
struct stud
{
    var rollno:Int
    var name:String
}

var student=stud(rollno: 1, name: "Manish")
print("Roll No= ", student.rollno)
print("Name = ", student.name)

