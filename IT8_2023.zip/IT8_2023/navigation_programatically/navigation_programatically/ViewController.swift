//
//  ViewController.swift
//  navigation_programatically
//
//  Created by MAC on 3/4/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func firstVC(_ sender: Any) {
        let fvc = self.storyboard?.instantiateViewController(identifier: "FirstViewController") as! FirstViewController
        self.navigationController?.pushViewController(fvc, animated: true)
    }
    
    @IBAction func SecondVC(_ sender: Any) {
        let svc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(svc, animated: true)
    }
}

