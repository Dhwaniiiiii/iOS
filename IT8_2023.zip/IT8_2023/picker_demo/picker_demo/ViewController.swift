//
//  ViewController.swift
//  picker_demo
//
//  Created by MAC on 3/1/23.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component==0
        {
            return city.count
        }
        if component==1
        {
            return trans.count
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component==0
        {
            return city[row]
        }
        if component==1
        {
            return trans[row]
        }
        return nil
       
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        l1.text=city[row] + trans[row]
    }
    @IBOutlet weak var l1: UILabel!
    @IBOutlet weak var mypicker: UIPickerView!
    var city:[String]=["Surat","Mumbai","Navsari"]
    var trans:[String]=["Cabs", "BRTS","Rickshaw"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.mypicker.delegate=self
        self.mypicker.dataSource=self
    }


}

