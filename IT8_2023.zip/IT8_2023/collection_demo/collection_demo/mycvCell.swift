//
//  mycvCell.swift
//  collection_demo
//
//  Created by MAC on 3/21/23.
//

import UIKit

class mycvCell: UICollectionViewCell {
    @IBOutlet weak var mylbl: UILabel!
    
}
