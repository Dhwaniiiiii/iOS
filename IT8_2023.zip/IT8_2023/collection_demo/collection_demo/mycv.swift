//
//  mycv.swift
//  collection_demo
//
//  Created by MAC on 3/21/23.
//

import UIKit

private let reuseIdentifier = "Cell"

class mycv: UICollectionViewController {
    var city:[String]=["Surat", "Mumbai", "Pune", "Navsari"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
    
        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")

        // Do any additional setup after loading the view.
    }

  

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return city.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? mycvCell
    
        // Configure the cell
        cell?.mylbl.text=self.city[indexPath.item]
    
        return cell!
    }

   

   

}
