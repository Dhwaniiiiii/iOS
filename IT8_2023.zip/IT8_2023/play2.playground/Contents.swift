import UIKit

// iOS Collections

//Array
/*
//var  nums:Array<Int> = [1,2,3,4,5]
var  names:Array<String> = ["Manish", "Bharat", "Ravi"]
//print(names)
//print(names.isEmpty)
//print(names.count)
//names.append("Aakash")
//names.remove(at: 0)
for i in names
{
    print(i)
}
*/

//Dictionary
/*
var d = Dictionary<String,String>()
 d = ["1":"Bharat", "2":"Ravi", "3":"Manish"]
//print(d.keys)
//print(d.values)
//print(d["1"]!)
//d = ["5": "Aakash"]
//d.updateValue("Aakash", forKey: "1")
//d.removeValue(forKey: "3")
//print(d.count)
for i in d{
    print(i.value)
}
*/

// Set
/*
var s1 = Set<Int>()
var s2 = Set<Int>()
s1 = [4, 2, 8, 10, 1]
s2 = [1, 2, 3, 4, 5]
//print(s1.union(s2))
//print(s1.intersection(s2))
print(s2.subtracting(s1))
*/



// Function in iOS
/*
func show()
{
    print("Welcome to iOS Programming...")
}

func show(a:Int)
{
    print("Value of a = ",a)
}
 */
func show(a:Int) -> Int
{
   return a*5
    
}

var b=show(a:20)
print("b = ",b)
