//
//  ViewController.swift
//  IT8_demo2
//
//  Created by MAC on 1/19/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
    }

    @IBAction func btn_click(_ sender: Any) {
        label1.text="iOS Prog..."
        label1.textColor = .red
    }
    
}

