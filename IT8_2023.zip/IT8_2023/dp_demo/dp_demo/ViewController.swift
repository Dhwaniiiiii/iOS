//
//  ViewController.swift
//  dp_demo
//
//  Created by MAC on 3/4/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var l1: UILabel!
    @IBOutlet weak var mydp: UIDatePicker!
    let df = DateFormatter()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        df.dateFormat = "dd/MM/YY"
        mydp.datePickerMode = .date
        l1.text = df.string(from: mydp.date)
    }


    
    @IBAction func date_changed(_ sender: Any) {
        l1.text = df.string(from: mydp.date)
    }
}

