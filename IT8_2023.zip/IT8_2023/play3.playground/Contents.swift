

import UIKit


class abc{
    var fname:String?
    var lname:String?
    var full:String?
    init(fn:String, ln:String) {
        self.fname=fn
        self.lname=ln
    }
    init(fullname:String) {
        self.full=fullname
    }
    func show()
    {
        print("welcome \(fname!) \(lname!)")
    }
    func disp()
    {
        print("welcome \(full!) ")
    }
}
class xyz: abc {
   override func  show()
    {
        print("Welcome to iOS......")
    }
}

var obj=xyz.init(fn: "Manish", ln: "Patel")
var obj2=abc.init(fn: "Manish", ln: "Patel")
var obj1=xyz.init(fullname: "Bharat Patel")
//var n:AnyObject?
var i:Int=2
if i==1 {
   
    obj.show()
}
if i==2
{
    obj2.show()
}

obj1.disp()
