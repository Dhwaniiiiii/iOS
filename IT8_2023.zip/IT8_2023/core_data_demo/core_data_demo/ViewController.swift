//
//  ViewController.swift
//  core_data_demo
//
//  Created by MAC on 3/2/23.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    @IBOutlet weak var id: UITextField!
    
    @IBOutlet weak var name: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
    }

    @IBAction func btn_add(_ sender: Any) {
        let appD=UIApplication.shared.delegate as! AppDelegate
        let context=appD.persistentContainer.viewContext
        let newitem=NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context)
        newitem.setValue(Int(id.text!), forKey: "eid")
        newitem.setValue(name.text, forKey: "ename")
        do{
            try context.save()
            print("Record inserted.....")
        }catch
        {
            print("Error in inserting record....")
        }
        
    }
    
    @IBAction func btn_display(_ sender: Any) {
        let appD2=UIApplication.shared.delegate as! AppDelegate
        let context2=appD2.persistentContainer.viewContext
        let fr=NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        do{
            let test = try context2.fetch(fr)
            for i in test as! [NSObject]
            {
                print(i.value(forKey: "eid")!)
                print(i.value(forKey: "ename")!)
            }
        }catch
        {
            
        }
    }
}

