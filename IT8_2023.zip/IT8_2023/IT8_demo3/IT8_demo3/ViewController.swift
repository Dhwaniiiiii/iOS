//
//  ViewController.swift
//  IT8_demo3
//
//  Created by MAC on 1/20/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var t1: UITextField!
    @IBOutlet weak var l1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btn_click(_ sender: Any) {
        var a:Int?  = Int(t1.text!)! * 2
        l1.text=String(a!)
    }
    

}

