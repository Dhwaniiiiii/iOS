import UIKit

let str = "Hello, playground"
//str="iOS Programming"
print(str)
