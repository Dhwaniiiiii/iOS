//
//  ViewController.swift
//  IT_8th_Demo1
//
//  Created by MAC on 1/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Label1.text="iOS Prog.."
    }


}

