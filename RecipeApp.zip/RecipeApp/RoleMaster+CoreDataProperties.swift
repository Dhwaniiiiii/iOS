//
//  RoleMaster+CoreDataProperties.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//
//

import Foundation
import CoreData


extension RoleMaster {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<RoleMaster> {
        return NSFetchRequest<RoleMaster>(entityName: "RoleMaster")
    }

    @NSManaged public var roleId: Int32
    @NSManaged public var roleName: String?
    @NSManaged public var toRegister: NSSet?

}

// MARK: Generated accessors for toRegister
extension RoleMaster {

    @objc(addToRegisterObject:)
    @NSManaged public func addToToRegister(_ value: RegisterMaster)

    @objc(removeToRegisterObject:)
    @NSManaged public func removeFromToRegister(_ value: RegisterMaster)

    @objc(addToRegister:)
    @NSManaged public func addToToRegister(_ values: NSSet)

    @objc(removeToRegister:)
    @NSManaged public func removeFromToRegister(_ values: NSSet)

}

extension RoleMaster : Identifiable {

}
