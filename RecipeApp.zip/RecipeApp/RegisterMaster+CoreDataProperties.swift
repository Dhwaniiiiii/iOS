//
//  RegisterMaster+CoreDataProperties.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//
//

import Foundation
import CoreData


extension RegisterMaster {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<RegisterMaster> {
        return NSFetchRequest<RegisterMaster>(entityName: "RegisterMaster")
    }

    @NSManaged public var email: String?
    @NSManaged public var gender: String?
    @NSManaged public var password: String?
    @NSManaged public var phoneNo: Int32
    @NSManaged public var registerId: Int32
    @NSManaged public var roleId: Int32
    @NSManaged public var userName: String?
    @NSManaged public var toRecipeMstr: NSSet?
    @NSManaged public var toRole: RoleMaster?

}

// MARK: Generated accessors for toRecipeMstr
extension RegisterMaster {

    @objc(addToRecipeMstrObject:)
    @NSManaged public func addToToRecipeMstr(_ value: RecipeMaster)

    @objc(removeToRecipeMstrObject:)
    @NSManaged public func removeFromToRecipeMstr(_ value: RecipeMaster)

    @objc(addToRecipeMstr:)
    @NSManaged public func addToToRecipeMstr(_ values: NSSet)

    @objc(removeToRecipeMstr:)
    @NSManaged public func removeFromToRecipeMstr(_ values: NSSet)

}

extension RegisterMaster : Identifiable {

}
