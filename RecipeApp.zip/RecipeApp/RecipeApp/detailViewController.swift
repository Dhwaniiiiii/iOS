//
//  detailViewController.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//

import UIKit
import CoreData

class detailViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    @IBOutlet weak var txtdId: UITextField!
    var recipe:[RecipeMaster] = []
    var rId:Int32 = 0
    var rdata:RecipeMaster?
    @IBOutlet weak var txtStep: UITextField!
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return recipe.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return recipe[row].itemName
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        rId = recipe[row].recipeId
    }
    
    func fetchRecipeMaster(){
        let appD = UIApplication.shared.delegate as! AppDelegate
        let con = appD.persistentContainer.viewContext
        
        let result = NSFetchRequest<RecipeMaster>(entityName: "RecipeMaster")
        
        do{
            recipe = try! con.fetch(result)
            
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchRecipeMaster()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func AddRecipeDetails(_ sender: Any) {
        let appD = UIApplication.shared.delegate as! AppDelegate
        let con = appD.persistentContainer.viewContext
        
        let obj = RecipeDetails(context: con)
        
        obj.recipeDetailId = Int32(txtdId.text!)!
        obj.recipeId = rId
        obj.steps = txtStep.text
        
        rdata?.addToToDetail(obj)
        do{
            try! con.save()
            print("Details is added")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
