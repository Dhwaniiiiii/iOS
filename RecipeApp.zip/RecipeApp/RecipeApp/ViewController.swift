//
//  ViewController.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        let adminNav = self.storyboard?.instantiateViewController(withIdentifier: "UserTab") as! RecipeMasterViewController
        
        self.navigationController?.pushViewController(adminNav, animated: true)
    }
    

}

