//
//  SignUpViewController.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//

import UIKit
import CoreData

class SignUpViewController: UIViewController , UIPickerViewDelegate ,UIPickerViewDataSource{
    
    var gender:[String] = ["Male","Female","Other"]
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return gender.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return gender[row]
    }
    
    var selectedGender:String = ""
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedGender = gender[row]
    }
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var txtRegisterId: UITextField!
    
    @IBOutlet weak var txtPhoneNo: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnRegister(_ sender: Any) {
        let AppD = UIApplication.shared.delegate as! AppDelegate
        let conn = AppD.persistentContainer.viewContext
        
        let obj = RegisterMaster(context: conn)
        
        obj.email = txtEmail.text
        obj.userName = txtName.text
        obj.password = txtPassword.text
        obj.registerId = Int32(txtRegisterId.text!)!
        obj.phoneNo = Int32(txtPhoneNo.text!)!
        obj.gender = selectedGender
        obj.roleId = 2
        
        do {
            try! conn.save()
            print("Registration Success....")
            
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            
            print(path[0])
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
