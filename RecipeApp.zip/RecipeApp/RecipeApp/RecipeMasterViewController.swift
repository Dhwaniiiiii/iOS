//
//  RecipeMasterViewController.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//

import UIKit
import CoreData

class RecipeMasterViewController: UIViewController {

    @IBOutlet weak var txtRecipeId: UITextField!
    
    @IBOutlet weak var txtRecipeName: UITextField!
    
    @IBOutlet weak var txtRecipeImage: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  
    @IBAction func btnInsertRecipe(_ sender: Any) {
        let appD = UIApplication.shared.delegate as! AppDelegate
        let con = appD.persistentContainer.viewContext
        
        let obj = RecipeMaster(context: con)
        obj.recipeId = Int32(txtRecipeId.text!)!
        obj.itemName = txtRecipeName.text
        obj.itemImage = txtRecipeImage.text
        obj.createdBy = 1
        
        do{
            try! con.save()
            print("Recipe Added...")
            
            let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            
            print(dirPath[0])
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
