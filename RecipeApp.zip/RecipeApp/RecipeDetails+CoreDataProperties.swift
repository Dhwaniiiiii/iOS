//
//  RecipeDetails+CoreDataProperties.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//
//

import Foundation
import CoreData


extension RecipeDetails {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<RecipeDetails> {
        return NSFetchRequest<RecipeDetails>(entityName: "RecipeDetails")
    }

    @NSManaged public var recipeDetailId: Int32
    @NSManaged public var recipeId: Int32
    @NSManaged public var steps: String?
    @NSManaged public var toRecipeMaster: RecipeMaster?

}

extension RecipeDetails : Identifiable {

}
