//
//  RecipeMaster+CoreDataProperties.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//
//

import Foundation
import CoreData


extension RecipeMaster {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<RecipeMaster> {
        return NSFetchRequest<RecipeMaster>(entityName: "RecipeMaster")
    }

    @NSManaged public var createdBy: Int32
    @NSManaged public var itemImage: String?
    @NSManaged public var itemName: String?
    @NSManaged public var recipeId: Int32
    @NSManaged public var toCreatedBy: RegisterMaster?
    @NSManaged public var toDetail: NSSet?

}

// MARK: Generated accessors for toDetail
extension RecipeMaster {

    @objc(addToDetailObject:)
    @NSManaged public func addToToDetail(_ value: RecipeDetails)

    @objc(removeToDetailObject:)
    @NSManaged public func removeFromToDetail(_ value: RecipeDetails)

    @objc(addToDetail:)
    @NSManaged public func addToToDetail(_ values: NSSet)

    @objc(removeToDetail:)
    @NSManaged public func removeFromToDetail(_ values: NSSet)

}

extension RecipeMaster : Identifiable {

}
