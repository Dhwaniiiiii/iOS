//
//  RegisterMaster+CoreDataClass.swift
//  RecipeApp
//
//  Created by MSCICT2 on 12/04/24.
//
//

import Foundation
import CoreData

@objc(RegisterMaster)
public class RegisterMaster: NSManagedObject {

}
